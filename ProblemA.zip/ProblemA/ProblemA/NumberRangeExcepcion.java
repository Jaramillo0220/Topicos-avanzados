//Clase que nos permite una excepción personalizada
public class NumberRangeExcepcion extends Exception {
    public NumberRangeExcepcion(String mensaje) {
        super(mensaje);
    }
}